package fm.dinamica1067.radio

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import android.content.ComponentName

class MainActivity : AppCompatActivity() {
    private var controller: MediaController? = null
    private lateinit var playButton: Button
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        playButton = findViewById(R.id.playButton)
        status = findViewById(R.id.status)

        playButton.setOnClickListener {
            val player = controller
            if (player == null) {
                status.text = "Conectando con la emisora…"
                connectController()
            } else if (player.isPlaying) {
                player.pause()
                updateUi()
            } else {
                player.play()
                updateUi()
            }
        }
        connectController()
    }

    private fun connectController() {
        if (controller != null) return
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            try {
                controller = future.get()
                controller?.addListener(object : androidx.media3.common.Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) = updateUi()
                    override fun onPlaybackStateChanged(playbackState: Int) = updateUi()
                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        status.text = "No se pudo conectar. Revisa tu internet e intenta otra vez."
                        playButton.text = "▶  INTENTAR DE NUEVO"
                    }
                })
                controller?.play()
                updateUi()
            } catch (_: Exception) {
                status.text = "No se pudo conectar. Intenta nuevamente."
                playButton.text = "▶  INTENTAR DE NUEVO"
            }
        }, java.util.concurrent.Executor { command -> command.run() })
    }

    private fun updateUi() {
        runOnUiThread {
            val playing = controller?.isPlaying == true
            status.text = if (playing) "● EN VIVO" else "Lista para reproducir"
            playButton.text = if (playing) "Ⅱ  PAUSAR" else "▶  ESCUCHAR EN VIVO"
        }
    }

    override fun onStart() {
        super.onStart()
        if (controller == null) connectController()
    }

    override fun onStop() {
        // Do not release the media session here: playback continues in the service
        super.onStop()
    }

    override fun onDestroy() {
        controller?.release()
        controller = null
        super.onDestroy()
    }
}
