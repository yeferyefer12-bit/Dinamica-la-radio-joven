DINÁMICA 106.7 FM — PROYECTO ANDROID

Este paquete contiene el código fuente de una aplicación Android de radio.
Emisora: Dinámica 106.7 FM
Streaming configurado: https://stream.zeno.fm/xzc4strbxzzuv

FUNCIONES INCLUIDAS
- Reproducción de radio por internet.
- Audio en segundo plano mediante Media3 MediaSessionService.
- Controles de reproducción desde la notificación/controles multimedia de Android.
- Interfaz sencilla con botón escuchar/pausar.
- Permiso de internet; no solicita ubicación, contactos ni otros datos personales.

IMPORTANTE: ESTADO DEL PAQUETE
Este es el PROYECTO FUENTE, no un APK/AAB compilado ni una publicación en Google Play.
En este entorno no está instalado Android SDK/Gradle, así que no puedo compilar ni probar el binario aquí.
Antes de publicar:
1. Confirma que tienes autorización del titular de Dinámica 106.7 FM para distribuir su nombre, marca y señal.
2. Sustituye el icono provisional por el logo oficial si tienes permiso.
3. Añade datos reales del desarrollador y un correo de soporte.
4. Publica una política de privacidad en una URL pública. Plantilla: PRIVACY_POLICY_TEMPLATE_ES.txt.
5. Compila y prueba en varios teléfonos, con pantalla apagada, cambio de red, llamadas y desconexiones.
6. En Google Play Console completa la ficha, clasificación de contenido, seguridad de datos y pruebas requeridas.
7. Para una app nueva en noviembre de 2026, Google Play exige target Android 16 / API 36 o superior.

IDENTIFICADOR
fm.dinamica1067.radio

No se debe afirmar que la aplicación ya está aprobada o publicada en Play Store. Google realiza su propia revisión.

COMPILACIÓN EN LA NUBE DESDE EL TELÉFONO
Se añadió .github/workflows/android-apk.yml para compilar automáticamente un APK de prueba en GitHub Actions.
1. En GitHub crea un repositorio nuevo llamado Dinamica1067FM.
2. Sube el contenido de este ZIP al repositorio (debe quedar la carpeta app/ y el archivo .github/ en la raíz).
3. Abre la pestaña Actions y selecciona “Build Android APK”; pulsa “Run workflow” si no comenzó automáticamente.
4. Cuando termine en verde, abre la ejecución y descarga el artefacto “Dinamica1067FM-debug-apk”.
5. Descomprime el artefacto y abre app-debug.apk en Android para instalarlo. Permite instalar desde esa fuente si Android lo solicita.
El APK debug es para prueba manual; para Google Play se necesitará un AAB firmado de producción.
